const express = require('express');
const router = express.Router();

const GPTController = require('../controllers/GPTController');

router.get('/list', GPTController.list);
router.post('/create', GPTController.create);
router.get('/get/:id', GPTController.get);
router.post('/update/:id', GPTController.update);
router.post('/delete', GPTController.delete);

module.exports = router;